# KaamSet Merchant Lab — Sharma Daily Mart

FICTIONAL STORE · SIMULATED PAYMENTS AND CUSTOMER CHANNELS
Actual Foundation model, PostgreSQL and cloud workers perform the application work.
This is not an official Paytm dashboard or statement. No money moves.

## Five-minute presentation
1. Open Merchant Lab and authorize its displayed demo capabilities. Show the actual synchronized transaction count and source memory status.
2. In AI Team Activity, run Milan's ₹2,480 cafe invoice job. Show the invoice, actual model/source evidence and the demo customer message.
3. In Payment Requests, simulate success. Open its transaction and linked invoice. Outstanding is now zero; future reminders are cancelled. Show the same IDs in the other KaamSet view.
4. Run Riya's hamper enquiry. Reply as the demo customer: “Yes, I confirm one ₹499 hamper with ₹30 delivery within 3 km in Mansarovar, total ₹529.” Wait for the actual agent order/request and simulate the payment.
5. Run Naina's settlement review: successful collection remains separate from bank settlement. Show the owner review and no payment reminder. Open the website studio, approve the fictional assets and publish with Vijay; open only the returned published URL.

## Other checks
Milo: run the wholesale quote, then reply “Please schedule a discussion tomorrow.” The resulting commitment is explicitly simulated, not a Google Calendar event.
Cloud execution: queue an authorized job, close the merchant tab, supply the customer payment in the other tab, reopen and inspect durable results.
Presenter: duplicate the latest payment event, advance only the demo follow-up clock, disconnect/reconnect a simulated customer channel, or reset ONLY this Lab session.
Reset preserves real accounts, connections, credentials and AI usage. Guests expire after 24 hours; this is not indefinite production hosting.

## Real connections (separate)
Use KaamSet Connections to connect and verify your own Gmail, Calendar or supported Instagram professional account. For WhatsApp, pair your own linked device and enable the desired reply team. Live automation requires current permissions, an eligible genuine inbound conversation or an authorized test recipient, and explicit sending approval. Fictional contacts are never live recipients.
Paytm staging/production require a genuine merchant MID and key. Set those through the protected account Connections form; never put keys in reports or the chat. Demo events use an internal KaamSet HMAC, not a Paytm checksum. Settlement Order Detail is an official production-only capability; our fixture simulation does not establish production access.

## Sources and financial definitions
Catalogue and consent are merchant-owned fixtures, separate from Paytm-shaped payment history.
Collected = gross successful simulated transactions; settlements = net completed payout batches; unsettled = expected net pending/exception batches plus unbatched successful transactions; refunds = successful fixture refunds; receivable = accepted non-cancelled/non-disputed invoice balances.
Fixture card commission 1%, tax on that commission 18%, UPI commission zero are SIMULATION ASSUMPTIONS, not actual Paytm pricing. Imported/sample records are not external payment evidence.
